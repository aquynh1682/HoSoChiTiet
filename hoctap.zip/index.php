<?php
    include 'connect.php';
    session_start();
    $user = (isset($_SESSION['user'])) ? $_SESSION['user']: [];
     //$user = $_SESSION['user'];
?> 

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Hỗ trợ học tập - đào tạo nhân tài quốc gia</title>
        <!-- <script src="jquery-3.6.0.min.js"></script> -->
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,700,800,900&amp;display=swap">

        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="style-noidung.css">
        <!-- <style>
        @media screen and (max-width: 800px) {
            #header,
            #nav,
            #banner,
            #feature,
            #footer {
                width: 100%;
            }
            }
    </style> -->


    </head>

    <body>
        <div id="container">
            <div id="header">
                <div class="container">
                    <div class="logo">
                        <!--
                        <a href="index.html">K12</p></a>
                        -->
                        <img src="anh/logo.png" alt="">
                    </div>
                    <div class="contac-info">
                        <ul>
                            <li>
                                <div class="contac-icon">
                                    <img src="anh/bay.png" alt="">
                                </div>

                                <div class="contac-text">
                                    <label>Email</label>
                                    <pan>Youremail@gmail.com</pan>
                                </div>
                            </li>

                            <li>
                                <div class="contac-icon">
                                    <img src="anh/call.png" alt="">
                                </div>

                                <div class="contac-text">
                                    <label>Call</label>
                                    <pan>0942 187 996</pan>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Start Menu -->

            <nav id="nav">
                <div class="container">
                    <div class="menu">
                        <ul class="root">
                            <li><a href="index.php">Trang Chủ</a></li>
                            <?php if(isset($user['name'])){?>
                                <li><a href="#">Chào: <?php echo $user['name'] ?></a></li>
                                <?php if(isset($user['access'])){?>
                                    <?php if($user['access']==0) {?>
                                        <li><a href="update.php">Đăng Bài</a></li>
                                    <?php }?>
                                <?php } ?>
                                <li><a href="logout.php">Đăng Xuất</a></li>
                            <?php }else { ?>
                                <li><a href="DangNhap.html">Đăng Nhập</a></li>
                                <li><a href="dangky.html">Đăng Ký</a></li>
                            <?php } ?>

                        </ul>
                        <div class="form-search">
                            <input type="text" class="keyword" placeholder="Search..." />
                            <button type="submit" class="btn-search">
                            <img src="anh/search.png" alt="">
                        </button>
                        </div>
                    </div>
                </div>
            </nav>
            <div class="banner">
                <img src="anh/hinh-nen-4k-dep_104739862.jpg" alt="">
            </div>
        </div>

        <!-- End Menu , start Noi Dung-->

        <div id="feature">
            <div class="container">
                <div class="feature-left">
                    <!-- ghi noi dung-->
                    <h2 class="feature-title"></h2>
                    <p class="desc"></p>

                    <div class="card">
                        <div class="icon">
                            <a href="math.html">
                                <img src="anh/math.png" url="math.html" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="math.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Toán</a>
                            </p>
                            <p>Writing research papers is an inevitable </p>
                        </div>
                    </div>

                    <div class="card">
                        <div class="icon">
                            <a href="vatly.html">
                                <img src="anh/vatly.png" url="math.html" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="vatly.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Vật Lý</a>
                            </p>
                            <p>Writing research papers is an inevitable </p>
                        </div>
                    </div>

                    <div class="card">
                        <div class="icon">
                            <a href="hoahoc.html">
                                <img src="anh/hoahoc.png" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="hoahoc.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Hóa Học</a>
                            </p>
                            <p>Writing research papers is an inevitable</p>
                            </a>
                        </div>
                    </div>

                    <div class="card">
                        <div class="icon">
                            <a href="sinhhoc.html">
                                <img src="anh/sinhhoc.png" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="sinhhoc.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Sinh Học</a>
                            </p>
                            <p>Writing research papers is an inevitable</p>
                            </a>
                        </div>
                    </div>

                    <div class="card">
                        <div class="icon">
                            <a href="history.html">
                                <img src="anh/history.png" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="history.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Lịch Sử</a>
                            </p>
                            <p>Writing research papers is an inevitable </p>
                            </a>
                        </div>
                    </div>

                    <div class="card">
                        <div class="icon">
                            <a href="dialy.html">
                                <img src="anh/dialy.png" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="dialy.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Địa Lý</a>
                            </p>
                            <p>Writing research papers is an inevitable</p>
                            </a>
                        </div>
                    </div>

                    <div class="card">
                        <div class="icon">
                            <a href="english.html">
                                <img src="anh/english.png" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="english.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">English</a>
                            </p>
                            <p>Writing research papers is an inevitable</p>
                            </a>
                        </div>
                    </div>



                    <div class="card">
                        <div class="icon">
                            <a href="khoahocxahoi.html">
                                <img src="anh/khoahocxahoi.png" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="khoahocxahoi.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Khoa Học và Xã Hội</a>
                            </p>
                            <p>Writing research</p>
                            </a>
                        </div>

                    </div>

                    <div class="card">
                        <div class="icon">
                            <a href="tonghop.html">
                                <img src="anh/iq.png" alt="">
                            </a>
                        </div>
                        <div class="font">
                            <p class="font-title">
                                <a href="tonhhop.html" onmouseenter="this.style.backgroundColor='gray' " onmouseleave="this.style.backgroundColor=''">Tổng Hợp</a>
                            </p>
                            <p>Writing research papers is an inevitable</p>
                            </a>
                        </div>
                    </div>




                </div>

            </div>
        </div>


        <!-- End Noi Dung , Start Footer  -->

        <!--
    <div id="service"> service</div>
    <div class="guidance">
        <h2> what your name ?</h2>
    </div>
    <div id="project">project</div>

    -->
        <div id="footer">
            <div class="container">
                <div class="logo">
                    <a href="">k12htht.xyz</a>
                    <h3>Website thi và tạo đề thi trắc nghiệm online. Mang đến người dùng các chức năng tốt nhất cho việc học tập và giảng dậy.</h3>
                </div>
                <div class="contac-info">
                    <a href="">Liên hệ</a>
                    <ul>
                        <li>
                            <div class="contac-icon">
                                <img src="anh/mail.png" alt="">
                            </div>

                            <div class="contac-text">
                                <label>Email</label>
                                <pan class="text">Youremail@gmail.com</pan>
                            </div>
                        </li>

                        <li>
                            <div class="contac-icon">
                                <img src="anh/call.png" alt="">
                            </div>

                            <div class="contac-text">
                                <label>Call</label>
                                <pan class="text">0942 187 996</pan>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <script>
            //lay vi tri hien tai cua menu cach top x px
            pos = $("#nav").position();

            $(window).scroll(function() {
                var posScroll = $(Document).scrollTop();
                if (parseInt(posScroll) > parseInt(pos.top)) {
                    $("#nav").addClass('fixed');
                } else {
                    $("#nav").removeClass('fixed');
                }
            });
        </script>
    </body>

    </html>