<?php
    include 'connect.php';
    session_start();
    if(isset($_POST['userName'])){
        $userName= $_POST['userName'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM user WHERE userName = '$userName'";
        $query = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($query);
        $checkUserName = mysqli_num_rows($query);
        if($checkUserName == 1){
            $checkPass = password_verify($password, $data['password']);
            if($checkPass){
                $_SESSION['user'] = $data;
                header('location: index.php');
                // $user = (isset($_SESSION['user'])) ? $_SESSION['user']: [];
                // var_dump($user['name']);
                // var_dump($_SESSION['user']);
            }
            else{
                echo "Tài khoản hoặc mật khẩu không đúng mời bạn nhập lại: <a href=\"javascript:history.go(-1)\">Nhấn vào đây!!!</a>";
            }
        }
        else{
            echo "Tài khoản hoặc mật khẩu không đúng mời bạn nhập lại: <a href=\"javascript:history.go(-1)\">Nhấn vào đây!!!</a>";
        }
    }
?>