<?php 
    include('connect_pdo.php');
    $search = $_GET['search'];
    $page = $_GET['page'];
    $sql = $conn->prepare("SELECT * FROM question WHERE question LIKE '%".$search."%' LIMIT 10 OFFSET ".($page-1)*10);
    $sql->execute();
    $index = 1;
    $data ='';
    while($result = $sql->fetch(PDO::FETCH_ASSOC)){
        $data.= '<tr id='.$result['id'].'>';
        $data.=  '<th scope="row">'.($index++).'</th>';
        $data.=  '<td class="text-primary">'.$result['question']."</td>";
        $data.=  '<td>';
        $data.=      '<input type="button" class = "btn btn-xs btn-info" value="Xem" name="view"> &nbsp;';
        $data.=      '<input type="button" class = "btn btn-xs btn-warning" value="Sửa" name = "update"> &nbsp;';
        $data.=      '<input type="button" class = "btn btn-xs btn-danger" value="Xoá" name = "delete"> &nbsp;';
        $data.=  '</td>';
        $data.= '</tr>';
    }
    echo $data;
?>